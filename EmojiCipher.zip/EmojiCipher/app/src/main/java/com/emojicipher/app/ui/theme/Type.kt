package com.emojicipher.app.ui.theme

import android.content.Context
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Loads Vazirmatn from assets/fonts if it is bundled (the build script downloads it).
 * Falls back to the system sans-serif so the app never fails because of a missing font file.
 */
fun loadAppFontFamily(context: Context): FontFamily {
    val files = try { context.assets.list("fonts")?.toSet() ?: emptySet() } catch (e: Exception) { emptySet() }
    val fonts = buildList<Font> {
        if ("Vazirmatn-Regular.ttf" in files) add(Font(context.assets, "fonts/Vazirmatn-Regular.ttf", FontWeight.Normal))
        if ("Vazirmatn-Medium.ttf" in files) add(Font(context.assets, "fonts/Vazirmatn-Medium.ttf", FontWeight.Medium))
        if ("Vazirmatn-Bold.ttf" in files) add(Font(context.assets, "fonts/Vazirmatn-Bold.ttf", FontWeight.Bold))
    }
    return if (fonts.isEmpty()) FontFamily.SansSerif else FontFamily(fonts)
}

/**
 * Persian is a joining script: any non-zero letter spacing breaks the joins, so it is forced to 0.
 */
fun appTypography(family: FontFamily): Typography {
    fun TextStyle.fix() = copy(fontFamily = family, letterSpacing = 0.sp, lineHeight = (fontSize.value * 1.55f).sp)
    val d = Typography()
    return Typography(
        displayLarge = d.displayLarge.fix(), displayMedium = d.displayMedium.fix(), displaySmall = d.displaySmall.fix(),
        headlineLarge = d.headlineLarge.fix(), headlineMedium = d.headlineMedium.fix(), headlineSmall = d.headlineSmall.fix(),
        titleLarge = d.titleLarge.fix(), titleMedium = d.titleMedium.fix(), titleSmall = d.titleSmall.fix(),
        bodyLarge = d.bodyLarge.fix(), bodyMedium = d.bodyMedium.fix(), bodySmall = d.bodySmall.fix(),
        labelLarge = d.labelLarge.fix(), labelMedium = d.labelMedium.fix(), labelSmall = d.labelSmall.fix()
    )
}
