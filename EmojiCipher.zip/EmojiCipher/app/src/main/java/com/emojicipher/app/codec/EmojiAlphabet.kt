package com.emojicipher.app.codec

/**
 * The fixed 256-symbol alphabet: one emoji per byte value (0..255).
 *
 * Compatibility rules used to choose the symbols (so they show up on every phone):
 *  - every symbol is a SINGLE Unicode code point (no ZWJ sequences, no skin tones,
 *    no flags, no keycaps);
 *  - every symbol has default emoji presentation, so no variation selector (U+FE0F)
 *    is needed to render it as a colour emoji;
 *  - every symbol was introduced in Unicode 6.0 or earlier (Emoji 1.0, 2010-2012),
 *    which is supported by Android 4.4+ and iOS 6+ and all current messengers.
 *
 * !!! DO NOT REORDER OR EDIT !!!  Index in this list == byte value.
 * Changing it breaks compatibility between installations; if it must change,
 * bump [EmojiCodec.FORMAT_VERSION] and keep the old table for decoding.
 */
internal object EmojiAlphabet {

    private val RANGES: List<IntRange> = listOf(
        0x1F300..0x1F320, // 33  weather / sky (cyclone .. shooting star)
        0x1F330..0x1F335, // 6   plants (chestnut .. cactus)
        0x1F337..0x1F37C, // 70  flowers, fruit, food, drink
        0x1F380..0x1F393, // 20  ribbon .. graduation cap
        0x1F3A0..0x1F3C4, // 37  carnival, sports
        0x1F3E0..0x1F3F0, // 17  buildings .. castle
        0x1F400..0x1F42F, // 48  animals
        0x1F5FB..0x1F5FF, // 5   mount fuji .. moai
        0x1F680..0x1F680, // 1   rocket
        0x1F525..0x1F525, // 1   fire
        0x1F48E..0x1F48E, // 1   gem
        0x2B50..0x2B50,   // 1   star
        0x2705..0x2705,   // 1   check mark button
        0x26A1..0x26A1,   // 1   high voltage
        0x1F493..0x1F49C, // 10  hearts
        0x1F4A1..0x1F4A1, // 1   light bulb
        0x1F4A5..0x1F4A5, // 1   collision
        0x1F4A7..0x1F4A8  // 2   droplet, dash
    )

    /** Index (byte value) -> code point. */
    val CODE_POINTS: IntArray = RANGES.flatMap { it.toList() }.toIntArray()

    /** Code point -> index (byte value). */
    val REVERSE: Map<Int, Int> = CODE_POINTS.withIndex().associate { (i, cp) -> cp to i }

    /** Index -> the symbol as a String. */
    val SYMBOLS: Array<String> = Array(CODE_POINTS.size) { String(Character.toChars(CODE_POINTS[it])) }

    init {
        check(CODE_POINTS.size == 256) { "Alphabet must contain exactly 256 symbols, has ${CODE_POINTS.size}" }
        check(REVERSE.size == 256) { "Alphabet contains duplicate symbols" }
    }
}
