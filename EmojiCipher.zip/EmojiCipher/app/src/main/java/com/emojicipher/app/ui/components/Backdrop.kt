package com.emojicipher.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.emojicipher.app.ui.theme.Navy
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Holds the sharp and the pre-blurred landscape plus the current darkening level.
 * Glass panels draw the pre-blurred picture at the exact position of the screen behind them,
 * which gives a real "frosted glass" look on every API level without an expensive runtime blur.
 */
class Backdrop(
    val sharp: ImageBitmap,
    val blurred: ImageBitmap,
    val widthPx: Float,
    val heightPx: Float,
    val dim: State<Float>
)

val LocalBackdrop = compositionLocalOf<Backdrop?> { null }

/** Draws [img] scaled to cover a w x h area (centre crop) at the current origin. */
fun DrawScope.drawCover(img: ImageBitmap, w: Float, h: Float) {
    val scale = max(w / img.width, h / img.height)
    val dw = img.width * scale
    val dh = img.height * scale
    drawImage(
        image = img,
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(img.width, img.height),
        dstOffset = IntOffset(((w - dw) / 2f).roundToInt(), ((h - dh) / 2f).roundToInt()),
        dstSize = IntSize(dw.roundToInt(), dh.roundToInt()),
        filterQuality = FilterQuality.Medium
    )
}

/** Navy overlay that keeps text readable; heavier towards the bottom like in the reference. */
fun DrawScope.drawDim(dim: Float, totalWidth: Float, totalHeight: Float) {
    val top = (dim * 0.80f).coerceIn(0f, 1f)
    val bottom = (dim + 0.30f * dim / 0.58f).coerceIn(0f, 0.96f)
    drawRect(
        Brush.verticalGradient(
            colors = listOf(Navy.copy(alpha = top), Navy.copy(alpha = bottom)),
            startY = 0f,
            endY = totalHeight
        ),
        size = androidx.compose.ui.geometry.Size(totalWidth, totalHeight)
    )
}

@Composable
fun AppBackground(backdrop: Backdrop, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        drawCover(backdrop.sharp, size.width, size.height)
        drawDim(backdrop.dim.value, size.width, size.height)
    }
}

@Composable
fun animatedDim(target: Float): State<Float> =
    animateFloatAsState(target, animationSpec = tween(450), label = "dim")
