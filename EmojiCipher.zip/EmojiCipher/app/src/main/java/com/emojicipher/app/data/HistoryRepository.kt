package com.emojicipher.app.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * Local history + simple app flags. Pure Kotlin (no Compose / Android types) so it can be unit tested.
 * Message contents are never written to the system log.
 */
class HistoryRepository(
    private val store: KeyValueStore,
    private val maxItems: Int = 200,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    companion object {
        private const val KEY_HISTORY = "history_json"
        private const val KEY_ENABLED = "history_enabled"
        private const val KEY_ONBOARDED = "onboarding_done"
    }

    var historyEnabled: Boolean
        get() = store.getBoolean(KEY_ENABLED, true)
        set(value) = store.putBoolean(KEY_ENABLED, value)

    var onboardingDone: Boolean
        get() = store.getBoolean(KEY_ONBOARDED, false)
        set(value) = store.putBoolean(KEY_ONBOARDED, value)

    /** Newest first. */
    fun load(): List<HistoryItem> {
        val raw = store.getString(KEY_HISTORY) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HistoryItem(
                    id = o.getLong("id"),
                    type = HistoryType.valueOf(o.getString("type")),
                    text = o.getString("text"),
                    emojis = o.getString("emojis"),
                    timestamp = o.getLong("ts")
                )
            }
        } catch (e: Exception) {
            emptyList() // corrupted storage must never crash the app
        }
    }

    /** Adds an item if history is enabled. Returns the new list (or the unchanged list if disabled). */
    fun add(type: HistoryType, text: String, emojis: String): List<HistoryItem> {
        val current = load()
        if (!historyEnabled) return current
        val now = clock()
        val nextId = (current.maxOfOrNull { it.id } ?: 0L) + 1L
        val updated = (listOf(HistoryItem(nextId, type, text, emojis, now)) + current).take(maxItems)
        save(updated)
        return updated
    }

    fun delete(id: Long): List<HistoryItem> {
        val updated = load().filterNot { it.id == id }
        save(updated)
        return updated
    }

    fun clear(): List<HistoryItem> {
        save(emptyList())
        return emptyList()
    }

    private fun save(items: List<HistoryItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("type", it.type.name)
                    .put("text", it.text)
                    .put("emojis", it.emojis)
                    .put("ts", it.timestamp)
            )
        }
        store.putString(KEY_HISTORY, arr.toString())
    }
}
