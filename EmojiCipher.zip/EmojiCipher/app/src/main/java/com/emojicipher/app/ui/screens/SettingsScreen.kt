package com.emojicipher.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Update
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emojicipher.app.AppState
import com.emojicipher.app.ui.components.ConfirmDialog
import com.emojicipher.app.ui.components.GlassTopBar
import com.emojicipher.app.ui.components.InfoDialog
import com.emojicipher.app.ui.components.glass
import com.emojicipher.app.ui.theme.TextMuted
import com.emojicipher.app.ui.theme.TextPrimary
import com.emojicipher.app.ui.theme.TextSecondary
import com.emojicipher.app.ui.theme.ToggleOn

private const val HELP_TEXT =
    "۱. در بخش «رمزگذاری پیام» متن خود را بنویسید و «تبدیل به ایموجی» را بزنید.\n" +
    "۲. نتیجه را کپی یا با «اشتراک‌گذاری» ارسال کنید.\n" +
    "۳. گیرنده باید همین برنامه را داشته باشد؛ پیام را در «ترجمه پیام» بچسباند و «ترجمه پیام» را بزند.\n\n" +
    "نکته: اگر پیام‌رسان نمادها را تغییر دهد یا حذف کند، برنامه پیام خراب را تشخیص می‌دهد و خطا نشان می‌دهد."

@Composable
fun SettingsScreen(state: AppState, onShowWelcome: () -> Unit) {
    var confirmClear by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        GlassTopBar("تنظیمات", onBack = null)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            SectionTitle("عمومی")
            SettingsGroup {
                SettingsRow(Icons.Rounded.Language, "زبان برنامه") { ValueText("فارسی") }
                RowDivider()
                SettingsRow(Icons.Rounded.DarkMode, "تم") { ValueText("تیره") }
                RowDivider()
                SettingsRow(
                    Icons.Rounded.Storage, "ذخیره تاریخچه",
                    onClick = { state.setHistoryEnabled(!state.historyEnabled) }
                ) {
                    Switch(
                        checked = state.historyEnabled,
                        onCheckedChange = { state.setHistoryEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White, checkedTrackColor = ToggleOn,
                            uncheckedThumbColor = Color.White.copy(alpha = 0.75f),
                            uncheckedTrackColor = Color.White.copy(alpha = 0.16f),
                            uncheckedBorderColor = Color.Transparent
                        )
                    )
                }
                RowDivider()
                SettingsRow(Icons.Rounded.DeleteSweep, "پاک کردن تاریخچه", onClick = { confirmClear = true }) {}
            }

            SectionTitle("درباره برنامه")
            SettingsGroup {
                SettingsRow(Icons.Rounded.Update, "نسخه") { ValueText(state.versionName()) }
                RowDivider()
                SettingsRow(Icons.Rounded.Info, "راهنما", onClick = { showHelp = true }) {}
                RowDivider()
                SettingsRow(Icons.Rounded.Slideshow, "نمایش صفحه‌ی خوش‌آمد", onClick = onShowWelcome) {}
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "این برنامه به‌صورت آفلاین کار می‌کند و نیازی به اینترنت ندارد.",
                color = TextSecondary, fontSize = 13.sp, lineHeight = 22.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "ایموجی‌ها فقط یک جایگزینی برگشت‌پذیر هستند، نه رمزنگاری امن. هر کسی که این برنامه را داشته باشد می‌تواند پیام را بخواند؛ پس اطلاعات حساس را با آن ارسال نکنید.",
                color = TextMuted, fontSize = 12.sp, lineHeight = 21.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            )
            Spacer(Modifier.height(130.dp))
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "پاک کردن تاریخچه",
            message = "همه‌ی موارد ذخیره‌شده برای همیشه حذف می‌شوند. ادامه می‌دهید؟",
            confirmLabel = "پاک کردن",
            onConfirm = { confirmClear = false; state.clearHistory() },
            onDismiss = { confirmClear = false }
        )
    }
    if (showHelp) InfoDialog("راهنما", HELP_TEXT) { showHelp = false }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 10.dp, start = 6.dp, end = 6.dp)
    )
}

@Composable
private fun SettingsGroup(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), tintAlpha = 0.40f)) { content() }
}

@Composable
private fun RowDivider() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(1.dp).background(Color.White.copy(alpha = 0.08f)))
}

@Composable
private fun ValueText(text: String) {
    Text(text, color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Start)
}

@Composable
private fun SettingsRow(
    icon: ImageVector,
    title: String,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 58.dp)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = TextSecondary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Text(title, color = TextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
        trailing()
    }
}
