package com.emojicipher.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.emojicipher.app.data.HistoryRepository
import com.emojicipher.app.data.SharedPrefsStore
import com.emojicipher.app.navigation.EmojiCipherApp
import com.emojicipher.app.ui.theme.EmojiCipherTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        val state = AppState(this, HistoryRepository(SharedPrefsStore(this)))
        setContent {
            EmojiCipherTheme { EmojiCipherApp(state) }
        }
    }
}
