package com.emojicipher.app.codec

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/**
 * Emoji Cipher codec - a deterministic, reversible emoji SUBSTITUTION.
 *
 * ***This is NOT encryption.*** Anyone who has this app (or this source file) can read the
 * message. It is meant for fun and light obfuscation only. It does not protect against
 * interception, analysis or tampering.
 *
 * Wire format (version 1). Every byte below is written as one emoji from [EmojiAlphabet]:
 *
 *     [MAGIC 0xEC] [VERSION 0x01] [payload: UTF-8 bytes of the text ...] [CRC16 hi] [CRC16 lo]
 *
 *  - MAGIC + VERSION: the first two emojis are always the same, so a message is recognisable
 *    and the format can evolve without breaking old messages.
 *  - payload: the exact UTF-8 bytes of the original string. No Unicode normalisation is done,
 *    so decode(encode(x)) == x for every valid string (Persian, English, digits, emoji, newlines).
 *  - CRC16 (CCITT-FALSE) over MAGIC+VERSION+payload: detects truncated, damaged or edited messages.
 *
 * Decoder leniency (messengers often alter whitespace): spaces, line breaks, zero-width characters,
 * direction marks and variation selectors are ignored. ANY other character is an error.
 *
 * Overhead: 4 emojis per message. Persian letters take 2 bytes (2 emojis), Latin letters 1,
 * emoji in the source text 4.
 *
 * Limitations: some messengers rewrite or strip emoji; the codec detects that (error), it cannot repair it.
 */
object EmojiCodec {

    const val FORMAT_VERSION = 1
    const val MAX_MESSAGE_CODE_POINTS = 5_000
    /** Longest possible encoded message: 5000 code points * 4 bytes + 4 bytes overhead. */
    const val MAX_ENCODED_SYMBOLS = MAX_MESSAGE_CODE_POINTS * 4 + 4
    /** Input limit used by the decode screen (leaves room for whitespace added by messengers). */
    const val MAX_DECODE_INPUT_CODE_POINTS = 25_000

    private const val MAGIC = 0xEC
    private const val HEADER_SIZE = 2
    private const val CRC_SIZE = 2

    // ---------- results ----------

    sealed class EncodeResult {
        data class Success(val emojis: String) : EncodeResult()
        data class Failure(val error: EncodeError) : EncodeResult()
    }

    sealed class DecodeResult {
        data class Success(val text: String) : DecodeResult()
        data class Failure(val error: DecodeError) : DecodeResult()
    }

    enum class EncodeError { EMPTY, TOO_LONG, INVALID_TEXT }

    sealed class DecodeError {
        object Empty : DecodeError()
        data class UnknownSymbol(val codePoint: Int) : DecodeError()
        object Truncated : DecodeError()
        object NotACipherMessage : DecodeError()
        data class UnsupportedVersion(val version: Int) : DecodeError()
        object Corrupted : DecodeError()
        object InvalidText : DecodeError()
        object TooLong : DecodeError()
    }

    // ---------- encode ----------

    fun encode(text: String): EncodeResult {
        if (text.isEmpty()) return EncodeResult.Failure(EncodeError.EMPTY)
        if (text.codePointCount(0, text.length) > MAX_MESSAGE_CODE_POINTS) {
            return EncodeResult.Failure(EncodeError.TOO_LONG)
        }
        val payload = strictUtf8Encode(text) ?: return EncodeResult.Failure(EncodeError.INVALID_TEXT)

        val frame = ByteArray(HEADER_SIZE + payload.size + CRC_SIZE)
        frame[0] = MAGIC.toByte()
        frame[1] = FORMAT_VERSION.toByte()
        System.arraycopy(payload, 0, frame, HEADER_SIZE, payload.size)
        val crc = crc16(frame, 0, HEADER_SIZE + payload.size)
        frame[frame.size - 2] = (crc ushr 8).toByte()
        frame[frame.size - 1] = crc.toByte()

        val sb = StringBuilder(frame.size * 2)
        for (b in frame) sb.append(EmojiAlphabet.SYMBOLS[b.toInt() and 0xFF])
        return EncodeResult.Success(sb.toString())
    }

    // ---------- decode ----------

    fun decode(input: String): DecodeResult {
        val bytes = ArrayList<Byte>()
        var i = 0
        while (i < input.length) {
            val cp = input.codePointAt(i)
            i += Character.charCount(cp)
            if (isIgnorable(cp)) continue
            val value = EmojiAlphabet.REVERSE[cp]
                ?: return DecodeResult.Failure(DecodeError.UnknownSymbol(cp))
            bytes.add(value.toByte())
            if (bytes.size > MAX_ENCODED_SYMBOLS) return DecodeResult.Failure(DecodeError.TooLong)
        }
        if (bytes.isEmpty()) return DecodeResult.Failure(DecodeError.Empty)

        if ((bytes[0].toInt() and 0xFF) != MAGIC) return DecodeResult.Failure(DecodeError.NotACipherMessage)
        if (bytes.size < HEADER_SIZE + 1 + CRC_SIZE) return DecodeResult.Failure(DecodeError.Truncated)
        val version = bytes[1].toInt() and 0xFF
        if (version != FORMAT_VERSION) return DecodeResult.Failure(DecodeError.UnsupportedVersion(version))

        val frame = bytes.toByteArray()
        val body = frame.size - CRC_SIZE
        val expected = ((frame[body].toInt() and 0xFF) shl 8) or (frame[body + 1].toInt() and 0xFF)
        if (crc16(frame, 0, body) != expected) return DecodeResult.Failure(DecodeError.Corrupted)

        val text = strictUtf8Decode(frame, HEADER_SIZE, body - HEADER_SIZE)
            ?: return DecodeResult.Failure(DecodeError.InvalidText)
        return DecodeResult.Success(text)
    }

    // ---------- helpers ----------

    /** Characters that chat apps / keyboards may insert or change. They never carry data. */
    private fun isIgnorable(cp: Int): Boolean =
        Character.isWhitespace(cp) || Character.isSpaceChar(cp) ||
            cp == 0xFE0F || cp == 0xFE0E ||          // variation selectors
            cp == 0x200B || cp == 0x200C || cp == 0x200D || // zero width space / non-joiner / joiner
            cp == 0x200E || cp == 0x200F ||          // LRM / RLM
            cp == 0x2066 || cp == 0x2067 || cp == 0x2068 || cp == 0x2069 || // isolates
            cp == 0x202A || cp == 0x202B || cp == 0x202C || cp == 0x202D || cp == 0x202E ||
            cp == 0x2060 || cp == 0xFEFF

    private fun strictUtf8Encode(text: String): ByteArray? = try {
        val buf = Charsets.UTF_8.newEncoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .encode(java.nio.CharBuffer.wrap(text))
        ByteArray(buf.remaining()).also { buf.get(it) }
    } catch (e: CharacterCodingException) {
        null // e.g. unpaired surrogate
    }

    private fun strictUtf8Decode(data: ByteArray, offset: Int, length: Int): String? = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(data, offset, length))
            .toString()
    } catch (e: CharacterCodingException) {
        null
    }

    /** CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF). */
    internal fun crc16(data: ByteArray, offset: Int, length: Int): Int {
        var crc = 0xFFFF
        for (k in offset until offset + length) {
            crc = crc xor ((data[k].toInt() and 0xFF) shl 8)
            repeat(8) {
                crc = if (crc and 0x8000 != 0) (crc shl 1) xor 0x1021 else crc shl 1
                crc = crc and 0xFFFF
            }
        }
        return crc
    }
}
