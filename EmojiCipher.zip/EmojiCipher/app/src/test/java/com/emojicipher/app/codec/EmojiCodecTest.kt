package com.emojicipher.app.codec

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EmojiCodecTest {

    private fun encodeOk(text: String): String {
        val r = EmojiCodec.encode(text)
        assertTrue("encode failed for: $text -> $r", r is EmojiCodec.EncodeResult.Success)
        return (r as EmojiCodec.EncodeResult.Success).emojis
    }

    private fun assertRoundTrip(text: String) {
        val encoded = encodeOk(text)
        assertEquals(EmojiCodec.DecodeResult.Success(text), EmojiCodec.decode(encoded))
    }

    private fun decodeError(input: String): EmojiCodec.DecodeError {
        val r = EmojiCodec.decode(input)
        assertTrue("expected failure for input, got $r", r is EmojiCodec.DecodeResult.Failure)
        return (r as EmojiCodec.DecodeResult.Failure).error
    }

    private fun cps(vararg v: Int) = v.joinToString("") { String(Character.toChars(it)) }

    // ---- 1-6 text kinds ----
    @Test fun persian() = assertRoundTrip("سلام داداش خوبی؟")
    @Test fun english() = assertRoundTrip("Good night")
    @Test fun mixedPersianEnglish() = assertRoundTrip("سلام Hello دنیا! این یک test است.")
    @Test fun numbers() = assertRoundTrip("1234567890")
    @Test fun persianDigitsAndArabicDigits() = assertRoundTrip("۱۲۳۴۵۶۷۸۹۰ ٠١٢٣٤٥٦٧٨٩")
    @Test fun punctuationAndSpecial() = assertRoundTrip("!@#$%^&*()_+-=[]{};':\",./<>?\\|`~ ؟،؛«»…—")
    @Test fun multipleSpaces() = assertRoundTrip("a   b    c      ")
    @Test fun tabsAndLeadingTrailingWhitespace() = assertRoundTrip("\t  hello  \t")

    // ---- 7 empty ----
    @Test fun emptyInputIsRejected() {
        assertEquals(EmojiCodec.EncodeResult.Failure(EmojiCodec.EncodeError.EMPTY), EmojiCodec.encode(""))
        assertEquals(EmojiCodec.DecodeError.Empty, decodeError(""))
        assertEquals(EmojiCodec.DecodeError.Empty, decodeError("  \n\t "))
    }

    // ---- 8 multiple lines ----
    @Test fun multipleLines() {
        assertRoundTrip("خط اول\nخط دوم\n\nline four\n")
        assertRoundTrip("windows\r\nline endings\r\n")
    }

    // ---- 9 long text ----
    @Test fun longText() {
        val sb = StringBuilder()
        while (sb.length < EmojiCodec.MAX_MESSAGE_CODE_POINTS) sb.append("سلام world ۱۲۳\n")
        assertRoundTrip(sb.substring(0, EmojiCodec.MAX_MESSAGE_CODE_POINTS))
    }

    @Test fun tooLongIsRejected() {
        val text = "x".repeat(EmojiCodec.MAX_MESSAGE_CODE_POINTS + 1)
        assertEquals(EmojiCodec.EncodeResult.Failure(EmojiCodec.EncodeError.TOO_LONG), EmojiCodec.encode(text))
    }

    @Test fun maxLengthWorstCaseDecodes() {
        // 5000 four-byte code points is the largest possible message.
        val text = "😀".repeat(EmojiCodec.MAX_MESSAGE_CODE_POINTS)
        assertRoundTrip(text)
    }

    // ---- 10 emoji inside the original message ----
    @Test fun emojiInOriginalMessage() {
        assertRoundTrip("سلام 😀 دنیا 🏔️ 👨‍👩‍👧‍👦 🇮🇷 👍🏽 ❤️")
    }

    @Test fun noUnicodeNormalisation() {
        val composed = "\u00E9"          // é
        val decomposed = "e\u0301"       // e + combining acute
        assertRoundTrip(composed)
        assertRoundTrip(decomposed)
        assertNotEquals(encodeOk(composed), encodeOk(decomposed))
        assertRoundTrip("\u200Fمتن\u200E با علامت جهت\u200C و نیم‌فاصله")
    }

    @Test fun unpairedSurrogateIsRejectedNotCorrupted() {
        assertEquals(
            EmojiCodec.EncodeResult.Failure(EmojiCodec.EncodeError.INVALID_TEXT),
            EmojiCodec.encode("abc\uD800def")
        )
    }

    // ---- 11 unknown emoji in encoded input ----
    @Test fun unknownEmojiInEncodedInput() {
        val encoded = encodeOk("Good night")
        val err = decodeError(encoded + "🚗")
        assertTrue(err is EmojiCodec.DecodeError.UnknownSymbol)
        assertEquals(0x1F697, (err as EmojiCodec.DecodeError.UnknownSymbol).codePoint)
        assertTrue(decodeError("hello world") is EmojiCodec.DecodeError.UnknownSymbol)
        assertTrue(decodeError(encoded.substring(0, 4) + "ا" + encoded.substring(4)) is EmojiCodec.DecodeError.UnknownSymbol)
    }

    // ---- 12 truncated / corrupted ----
    @Test fun truncatedMessages() {
        val encoded = encodeOk("سلام داداش خوبی؟")
        val symbols = encoded.codePoints().toArray()
        for (keep in 1 until symbols.size) {
            val partial = String(symbols, 0, keep)
            val r = EmojiCodec.decode(partial)
            assertTrue("truncated message with $keep symbols must not decode", r is EmojiCodec.DecodeResult.Failure)
        }
    }

    @Test fun corruptedSymbolIsDetected() {
        val symbols = encodeOk("Good night").codePoints().toArray()
        for (pos in symbols.indices) {
            val damaged = symbols.copyOf()
            // replace with a different (valid) alphabet symbol
            damaged[pos] = if (damaged[pos] == EmojiAlphabet.CODE_POINTS[0]) EmojiAlphabet.CODE_POINTS[1] else EmojiAlphabet.CODE_POINTS[0]
            val r = EmojiCodec.decode(String(damaged, 0, damaged.size))
            assertTrue("damage at $pos must be detected, got $r", r is EmojiCodec.DecodeResult.Failure)
        }
    }

    @Test fun swappedSymbolsAreDetected() {
        val symbols = encodeOk("Good night").codePoints().toArray()
        val swapped = symbols.copyOf()
        val t = swapped[3]; swapped[3] = swapped[4]; swapped[4] = t
        if (!swapped.contentEquals(symbols)) {
            assertTrue(EmojiCodec.decode(String(swapped, 0, swapped.size)) is EmojiCodec.DecodeResult.Failure)
        }
    }

    @Test fun notACipherMessage() {
        // valid alphabet symbols, but not starting with the magic byte
        val fake = EmojiAlphabet.SYMBOLS[1].repeat(10)
        assertEquals(EmojiCodec.DecodeError.NotACipherMessage, decodeError(fake))
    }

    @Test fun unsupportedVersion() {
        val frame = byteArrayOf(0xEC.toByte(), 0x7F, 0x41)
        val crc = EmojiCodec.crc16(frame, 0, frame.size)
        val full = frame + byteArrayOf((crc ushr 8).toByte(), crc.toByte())
        val encoded = full.joinToString("") { EmojiAlphabet.SYMBOLS[it.toInt() and 0xFF] }
        assertEquals(EmojiCodec.DecodeError.UnsupportedVersion(0x7F), decodeError(encoded))
    }

    // ---- 13 two independent instances: fixed golden vectors ----
    @Test fun goldenVectorsAreStableAcrossInstallations() {
        val goodNight = cps(
            0x1f680, 0x1f301, 0x1f357, 0x1f382, 0x1f382, 0x1f374, 0x1f320,
            0x1f381, 0x1f379, 0x1f377, 0x1f378, 0x1f387, 0x1f3af, 0x1f308
        )
        assertEquals(goodNight, encodeOk("Good night"))
        assertEquals(EmojiCodec.DecodeResult.Success("Good night"), EmojiCodec.decode(goodNight))

        val salam = cps(
            0x1f680, 0x1f301, 0x1f421, 0x1f3ed, 0x1f422, 0x1f3a3, 0x1f421, 0x1f3e1, 0x1f422, 0x1f3a4,
            0x1f320, 0x1f421, 0x1f3e9, 0x1f421, 0x1f3e1, 0x1f421, 0x1f3e9, 0x1f421, 0x1f3e1, 0x1f421,
            0x1f3ee, 0x1f320, 0x1f421, 0x1f3e8, 0x1f422, 0x1f3a7, 0x1f421, 0x1f3e2, 0x1f424, 0x1f3ab,
            0x1f421, 0x1f3be, 0x1f34e, 0x1f300
        )
        assertEquals(salam, encodeOk("سلام داداش خوبی؟"))
        assertEquals(EmojiCodec.DecodeResult.Success("سلام داداش خوبی؟"), EmojiCodec.decode(salam))
    }

    // ---- 14 repeated encoding ----
    @Test fun encodingIsDeterministic() {
        val first = encodeOk("سلام Hello ۱۲۳")
        repeat(50) { assertEquals(first, encodeOk("سلام Hello ۱۲۳")) }
    }

    // ---- messenger tolerance ----
    @Test fun decoderIgnoresWhitespaceAndInvisibleMarks() {
        val text = "سلام داداش"
        val encoded = encodeOk(text)
        val noisy = StringBuilder()
        var i = 0
        var n = 0
        while (i < encoded.length) {
            val cp = encoded.codePointAt(i)
            noisy.appendCodePoint(cp)
            i += Character.charCount(cp)
            when (n++ % 5) {
                0 -> noisy.append(' ')
                1 -> noisy.append('\n')
                2 -> noisy.append('\uFE0F')
                3 -> noisy.append('\u200F')
                else -> {}
            }
        }
        assertEquals(EmojiCodec.DecodeResult.Success(text), EmojiCodec.decode("  \n" + noisy + " \n"))
    }

    // ---- alphabet guarantees ----
    @Test fun alphabetIsExactly256UniqueSingleCodePoints() {
        assertEquals(256, EmojiAlphabet.CODE_POINTS.size)
        assertEquals(256, EmojiAlphabet.CODE_POINTS.toSet().size)
        for (s in EmojiAlphabet.SYMBOLS) assertEquals(1, s.codePointCount(0, s.length))
    }

    @Test fun alphabetAvoidsRiskyCodePoints() {
        for (cp in EmojiAlphabet.CODE_POINTS) {
            assertFalse("regional indicator", cp in 0x1F1E6..0x1F1FF)
            assertFalse("skin tone modifier", cp in 0x1F3FB..0x1F3FF)
            assertFalse("variation selector / joiner", cp == 0xFE0F || cp == 0xFE0E || cp == 0x200D)
            assertFalse("keycap / text-style symbol", cp == 0x20E3 || cp in 0x2190..0x21FF || cp in 0x2600..0x26FF && cp != 0x26A1)
            assertTrue("must be in Unicode 6.0 emoji blocks or be one of the 3 BMP emoji", cp >= 0x1F300 || cp == 0x2B50 || cp == 0x2705 || cp == 0x26A1)
        }
    }

    @Test fun everyByteValueRoundTrips() {
        // Every one of the 256 symbols must be usable as payload: build text whose UTF-8 hits many byte values.
        val text = (0x20..0x7E).map { it.toChar() }.joinToString("") + "ابپتثجچحخدذرزسشصضطظعغفقکگلمنوهی" + "😀🚀"
        assertRoundTrip(text)
    }
}
